﻿//Write a single method that calculates the area and circumference of the circle. The area and circumference should be displayed through the client code

using System;

class Circle
{
static double circumference(double r)
    {

        double PI = 3.1415;
        double cir = 2 * PI * r;
        return cir;
    }
  public static void Main()
    {

        double r ;
        Console.Write("Enter Radius: ");
        r = Convert.ToInt32(Console.ReadLine());
        double result =
              Math.Round(circumference(r)
                        * 1000) / 1000.0;

        Console.WriteLine("Circumference = "
                                  + result);
    }
}
