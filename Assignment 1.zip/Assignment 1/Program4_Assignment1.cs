﻿//Write a method to swap two integers. The client code should call the method and print the swapped value

using System;

class SwapValues
{
    public void  swap(int number1, int number2)
    {

        int temp;
        

        temp = number1;
        number1 = number2;
        number2 = temp;

        Console.Write("\nAfter Swapping : ");
        Console.Write("\nFirst Number : " + number1);
        Console.Write("\nSecond Number : " + number2);
        Console.Read();

    }
}

public class Exercise5
{
    public static void Main(string[] args)
    {
        int number1, number2;
        Console.Write("\nInput the First Number : ");
        number1 = int.Parse(Console.ReadLine());
        Console.Write("\nInput the Second Number : ");
        number2 = int.Parse(Console.ReadLine());
        SwapValues n = new SwapValues();

        n.swap(number1,number2);
        




    }
}
