﻿/*Assignments to be done in this session
1)	Create a hierarchy of Employee, Manager, MarketingExecutive in Employee Management System. They should have the following functionality.
a)	Manager with following private members.
	Petrol Allowance: 8 % of Salary.
	Food Allowance : 13 % of Salary.
	Other Allowances : 3 % of Salary.
Calculate GrossSalary by adding above allowances. Override CalculateSalary() method to calculate Net Salary. NetSalary. PF calculation should not consider above allowances.
b)	MarketingExecutive with following private members.
	Kilometer travel
	Tour Allowances : Rs 5/- per Kilometer (Automatically generated).
	Telephone Allowances : Rs.1000/-
Calculate GrossSalary by adding above allowances. Override CalculateSalary(). NetSalary,PF calculation should not consider above allowances.
Implement IPrintable interface for every Employee which will allow to print details of Employee on console.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1

{
    interface IPrintable
    {
        void Mprint();

    }
    public class Employee
    {

        public static void Main()
        {
            Console.Write("Enter the salary of an Employee  :");
            Manager m = new Manager(Convert.ToDouble(Console.ReadLine()));

           

            m.Foodie();
            m.Petrol();
            m.Others();

            m.GrossSalary();
            m.CalculateSalary();
            m.Mprint();

            Console.Write("Enter the salary of an Employee :");

            MarketingExecutive me = new MarketingExecutive(Convert.ToDouble(Console.ReadLine()));
            me.Grosssalary();
            me.CalculateSalary();
            me.Mprint();


        }

    }
    /*Manager class*/
    public class Manager : IPrintable
    {
        private double _Petrol;
        private double _Food;
        private double _Others;
        private double sal;
        private double Gross;
        private double Netsal;
        private double Pf, TDS;

        public Manager(double Esalary)
        {
            sal = Esalary;


            //  Console.WriteLine(sal);
        }
        public void Foodie()
        {
            _Food = sal * 0.13;

            //return _Food;
        }
        public void Petrol()
        {
            _Petrol = sal * 0.08;
            // return _Petrol;
        }
        public void Others()
        {
            _Others = sal * 0.03;

            //return _Others;
        }
        public void GrossSalary()
        {
            Gross = sal + _Food + _Petrol + _Others;

        }
        public void CalculateSalary()
        {
            Pf = (Gross * 0.10);
            TDS = (Gross * 0.18);
            Netsal = Gross - (Pf + TDS);
            // Console.WriteLine("Employee Salary:" + Netsal);

        }

        public void Mprint()
        {
            Console.WriteLine("Petrol Allowances:{0}", _Petrol);
            Console.WriteLine("Food Allowances:{0}", _Food);
            Console.WriteLine("Other Allowances:{0}", _Others);
            Console.WriteLine("Gross Salary with Allowances:{0}", Gross);
            Console.WriteLine("Net Salary:{0}", Netsal);
        }

    }
    /*Marketing Excutive Class*/
    public class MarketingExecutive : IPrintable
    {
        private double sal;
        private double KM;
        private double TourAllowances;
        private double TelephoneAllowances;
        private double Netsal, Pf, TDS, Gross;
        public MarketingExecutive(double Esal)
        {
            this.sal = Esal;
        }
        public void Grosssalary()
        {
            Console.Write("Enter the Total Kilometers Covered:");
            KM = Convert.ToDouble(Console.ReadLine());
            TourAllowances = 5 * KM;
            TelephoneAllowances = 1000;
            Gross = sal + TourAllowances + TelephoneAllowances;
            // Console.WriteLine(Gross);
        }

        public void CalculateSalary()
        {
            Pf = (Gross * 0.10);
            TDS = (Gross * 0.18);
            Netsal = Gross - (Pf + TDS);
            // Console.WriteLine("Employee Salary:" + Netsal);

        }
        public void Mprint()
        {
            Console.WriteLine("Travel Allowances:{0}", TourAllowances);
            Console.WriteLine("Telephone Allowances:{0}", TelephoneAllowances);
            Console.WriteLine("Gross salary with  Allowances:{0}", Gross);
            Console.WriteLine("Net Salary :{0}", Netsal);
        }

    }
}
