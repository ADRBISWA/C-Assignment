﻿/*Create a MultiCast Delegate by adding address of another method to the above delegate to list the details of Marketing Executive.*/


namespace MulticastDelegateDemo
{
    public delegate void MathDelegate(int No1, int No2);
    public class Program
    {
        public static void Add(int x, int y)
        {
            Console.WriteLine(" Summation value is : " + (x + y));
        }
        public static void Sub(int x, int y)
        {
            Console.WriteLine("Subtraction value is : " + (x - y));
        }
        public void Mul(int x, int y)
        {
            Console.WriteLine("Multiplication value is: " + (x * y));
        }
        public void Div(int x, int y)
        {
            Console.WriteLine("Division value is: " + (x / y));
        }

        static void Main(string[] args)
        {
            Program p = new Program();
            MathDelegate del5;
            MathDelegate del1 = new MathDelegate(Add);
            MathDelegate del2 = new MathDelegate(Program.Sub);
            MathDelegate del3 = p.Mul;
            MathDelegate del4 = new MathDelegate(p.Div); ;
            
            del5 = del1 + del2 + del3 + del4;
            del5.Invoke(10,20);
            Console.WriteLine();
            del5 -= del2;
            del5(75,5);

            Console.ReadKey();
        }
    }
}