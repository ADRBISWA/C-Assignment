﻿//Unicating program

using System;
namespace unicast
{
    public delegate int AddDelegate(int x,int y);

    class program
    {
        static void Main()
        {
            AddDelegate dlg = new AddDelegate(Add);
            int r = dlg.Invoke(15,85);
            Console.WriteLine("Summation value is {0}", r);
            Console.ReadKey();
        }
        public static int Add(int x, int y)
        {
            return (x + y);
        }
    }
}
