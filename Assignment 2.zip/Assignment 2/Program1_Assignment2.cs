﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace oop1b
{
    class emp
    {
        private string emp_name;
        private double emp_sal;
        private double emp_HRA;
        private double emp_DA;
        private double emp_TA;
        private double emp_TDS;
        private double emp_PF;
        private double emp_netsalary;
        private double emp_grosssalary;

        public emp()
        {
            name = emp_name;
            sal = emp_sal;

        }
        public string name
        {
            get { return emp_name; }
            set { emp_name = value; }
        }
        public double sal
        {
            get { return emp_sal; }
            set { emp_sal = value; }
        }


        public double calHRA()
        {
            if (emp_sal < 5000)
                emp_HRA = 10 % emp_sal;
            else if (emp_sal < 10000)
                emp_HRA = 15 % emp_sal;
            else if (emp_sal < 15000)
                emp_HRA = 20 % emp_sal;
            else if (emp_sal < 20000)
                emp_HRA = 25 % emp_sal;
            else if (emp_sal >= 20000)
                emp_HRA = 30 % emp_sal;
            return emp_HRA;


        }

        public double calDA()
        {
            if (emp_sal < 5000)
                emp_DA = 15 % emp_sal;
            else if (emp_sal < 10000)
                emp_DA = 20 % emp_sal;
            else if (emp_sal < 15000)
                emp_DA = 25 % emp_sal;
            else if (emp_sal < 20000)
                emp_DA = 30 % emp_sal;
            else if (emp_sal >= 20000)
                emp_DA = 35 % emp_sal;

            return emp_DA;
        }

        public double calTA()
        {
            if (emp_sal < 5000)
                emp_TA = 5 % emp_sal;
            else if (emp_sal < 10000)
                emp_TA = 10 % emp_sal;
            else if (emp_sal < 15000)
                emp_TA = 15 % emp_sal;
            else if (emp_sal < 20000)
                emp_TA = 20 % emp_sal;
            else if (emp_sal >= 20000)
                emp_TA = 25 % emp_sal;
            return emp_TA;
        }

        public double calgross()
        {

            emp_grosssalary = emp_HRA + emp_DA + emp_TA;
            return emp_grosssalary;

        }

        public double calPF()
        {
            emp_PF = 10 % emp_grosssalary;
            return emp_PF;
        }

        public double calTDS()
        {
            emp_TDS = 18 % emp_grosssalary;
            return emp_TDS;
        }
        public double calnetsal()
        {
            emp_netsalary = emp_grosssalary - (emp_PF + emp_TDS);
            return emp_netsalary;
        }



        public void display()
        {
            Console.WriteLine("Employee Name : " + name);
            Console.WriteLine("Employee Salary : " + sal);

            Console.WriteLine("Employee HRA: " + calHRA());
            Console.WriteLine("Employee DA : " + calDA());
            Console.WriteLine("Employee TA : " + calTA());
            Console.WriteLine("Employee Gross_Salary : " + calgross());
            Console.WriteLine("Employee  PF value: " + calPF());
            Console.WriteLine("Employee TDS value: " + calTDS());
            Console.WriteLine("Employee Net_Salary : " + calnetsal());

        }
    }



    class Program
    {
        static void Main(string[] args)
        {
            emp[] e = new emp[3];
            emp k = new emp();
            for (int i = 1; i <= 3; i++)
            {
                Console.WriteLine("Enter Employee Name : ");
                k.name = Console.ReadLine();
                Console.WriteLine("Enter Employee Salary : ");
                k.sal = Convert.ToDouble(Console.ReadLine());
                k.display();
                Console.WriteLine("\n------------------------------------\n");
            }
            Console.ReadKey();
        }
    }
}

