﻿/*Write Custom Generic class MyStack based on assignment of previous session, with
Push() and Pop() methods to store any kind of .NET Type.*/



using System;
using System.Collections;

class My_Stack
{

    // Main Method
    static public void Main()
    {

        // Create a stack
        // Using Stack class
        Stack my_stack = new Stack();

        // Adding elements in the Stack
        // Using Push method
        my_stack.Push("Adrija");
        my_stack.Push("Biswas");
        my_stack.Push('A');
        my_stack.Push('B');
        my_stack.Push(1234);
        my_stack.Push(987456);

        // Accessing the elements
        // of my_stack Stack
        // Using foreach loop
        foreach (var elem in my_stack)
        {
            Console.WriteLine(elem);
        }
        Console.WriteLine("Total elements present in before Pop the Elements" + " my_stack: {0}", my_stack.Count);
        
        my_stack.Pop();
        Console.WriteLine("The elements Presents in after pop function: ");
        foreach (var elem in my_stack)
        {
            Console.WriteLine(elem);
        }

        // After Pop method
        Console.WriteLine("Total elements present in " + "my_stack: {0}", my_stack.Count);




    }
}